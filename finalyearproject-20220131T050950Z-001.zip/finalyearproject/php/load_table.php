<?php
include 'dbcon.php';
$sql = "Select  Priceperkg, type_id from grabage_type  where type_name = '{$_POST['type_name']}' ";
$result = mysqli_query($con,$sql) or die("SQL query failed");

$output="";

if (mysqli_num_rows($result) > 0) {
    
while($row = mysqli_fetch_assoc($result)){
    
    
    $output = "{$row["Priceperkg"]}";
    $res['output']=$output;
    $res['typeID']="{$row["type_id"]}";
    
    
    
    

}
echo json_encode($res);

}else{
   // echo "no record found";
   echo $sql;
}
?>
