<?php 
include "dbcon.php";
if(session_status() == PHP_SESSION_NONE)
{
	session_start();//start session if session not start
}

if( isset($_POST['location']) &&  isset($_POST['dd']) ){
	$loc = $_POST['location'];
	
	$PickupDate = date('Y-m-d', strtotime($_POST['dd']));

	$_SESSION['loc'] = $loc;
	
	$_SESSION['Pickup_date'] = $PickupDate;
	$_SESSION['tracker'] = uniqid();

	$return['url'] = 'type.php?cat_id='.$_POST['cat_id'];
	$return['valid'] = true;

	echo json_encode($return);
}//end isset