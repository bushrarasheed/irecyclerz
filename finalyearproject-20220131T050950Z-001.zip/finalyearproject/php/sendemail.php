<?php
include 'dbcon.php'; 
if(isset($_POST["email"]) && isset($_POST["code"])){
    $to=$_POST["email"];
    $subject = "Email activation";
    $body = "Hi, $username.\n
    Click here too activate your account: \n
    http://localhost/finalyearproject/php/activate.php?token=$token \n";
       
       $message = '<html><body style="color:#f40;">';
       $message .= '<img src="logo.png" alt="image" style="width: 100px; height:100px;"> ';               ;
       $message .= '<p style="color:#080;font-size:18px;"></p>'.$body;
       $message .= '</body></html>';
    
       
       $sender_email = "From: irecyclerz@gmail.com";
       $from="irecyclerz@gmail.com";
       
       $header='';
       $header .= 'MIME-Version: 1.0' . "\r\n";
       $header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
       $header .= "From: $from \r\n" .
             "Reply-To: $from \r\n" .
             "X-Mailer: PHP/" . phpversion();
       //if (mail($email, $subject, $body, $sender_email)) {
          if (mail($email, $subject, $message, $header)) {
              $_SESSION['msg'] = "check you mail to activate your account $email";
              header('location:login.php');
          } else {
            echo "Email sending failed...";
         }
    
}
?>
if(isset($_POST["email"]) && isset($_POST["code"])){
    $to=$_POST["email"];
    $subject="Verify Code";
    $message="Click to Verify: \n"."http://localhost/emaillink/active.php?email=".$_POST["email"]."&code=".$_POST["code"];
    mail($to,$subject,$message);
    $con=new mysqli("localhost","root","","emaillink");
    if (mysqli_connect_errno()){
        die("unable to connect to database".mysqli_connect_errno());

    }
    $stmt=$con ->prepare("insert into user(email,state) values(?,?)");
    $stmt ->bind_param("ss",$_POST["email"],$_POST["code"]);
    if ($stmt ->execute()){
        echo "done";
    }
    mysqli_close($con);
}