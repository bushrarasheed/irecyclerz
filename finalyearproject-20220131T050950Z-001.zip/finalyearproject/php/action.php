<?php
if(!isset($_SESSION))
    session_start();
    // if (!isset($_SESSION['username'])) {
    //     include('newlogin.php');
    // }

    
?>
<?php
    include 'dbcon.php';    
    
    if (isset($_POST['submit'])) {
        $Type = mysqli_real_escape_string($con, $_POST['Type']);
        
        $date =date('Y-m-d', strtotime($_POST['date']));
        
        $uer_id = mysqli_real_escape_string($con, $_POST['uer_id']);

        $payment = mysqli_real_escape_string($con, $_POST['payment']);
        
        
        $sql = "insert into service(Type,date,uer_id,payment,Satus) values('$Type','$date','".$_SESSION['id']."','$payment','placed')";
        
        
        
        
        
        $iquery = mysqli_query($con, $sql);
        
  
        
        if ($iquery) {
           
            $subject = "Service Form";
            $email_body = "Your Type: $Type.".".Address: $location.\n\t".
                        
                        "\nandDate:$date.\n";
            $Email = "sumshafique@gmail.com";
        
            $to = "irecyclerz@gmail.com";
            
            $header='';
            $header .= 'MIME-Version: 1.0' . "\r\n";
            $header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $header .= "From: $Email \r\n" .
                    "Reply-To: $Email \r\n" .
                    "X-Mailer: PHP/" . phpversion();
            mail($to, $subject, $email_body, $header);
            
            

            $subject = "our service";
            $email_body = "Your Type: $Type.".".Address: $Address.\n\t".
                        
                        "\nandDate:$Pickup.\n"."\r\n";
            $email_body .= "thank you for using our service"."\r\n"; 
            $email_body .= "if you want to cancel order within hour click on this link"."\r\n";
            $Email = "sumshafique@gmail.com";
        
            $from = "irecyclerz@gmail.com";
            
            $header='';
            $header .= 'MIME-Version: 1.0' . "\r\n";
            $header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $header .= "From: $from \r\n" .
                    "Reply-To: $from \r\n" .
                    "X-Mailer: PHP/" . phpversion();
            mail($_SESSION['email'], $subject, $email_body, $header);
            
           
        }
    }
 ?>