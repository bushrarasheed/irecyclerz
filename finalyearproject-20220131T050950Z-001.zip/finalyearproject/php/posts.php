
 <?php
session_start();
include "dbcon.php";
  

  if(isset($_POST['submit'])){
                        $firstname = mysqli_real_escape_string($con, $_POST['firstname']) ;
                        $lastname = mysqli_real_escape_string($con, $_POST['lastname']) ;
                        $email = mysqli_real_escape_string($con, $_POST['email']) ;
                        $message = mysqli_real_escape_string($con, $_POST['message']) ;

                         $insertquery1 = "insert into posts (firstname,lastname,email,message) values ('$firstname','$lastname','$email','$message')";
                         $insertquery2 = "insert into notifications (firstname,lastname,email,message, read_n) values ('$firstname','$lastname','$email','$message', '1')";
                          $query_run = mysqli_query($con, $insertquery1);
                           $query_run = mysqli_query($con, $insertquery2);
                           
                           echo "Posted";
                           header("location:contact.php");
                        }

?>