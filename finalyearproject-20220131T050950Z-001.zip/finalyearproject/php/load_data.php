<?php
include 'dbcon.php';

$sql = "Select distinct(type_name) from grabage_type  WHERE  cat_id= '{$_POST['cat_id']}'";
$result = mysqli_query($con,$sql) ;

if(mysqli_num_rows($result) > 0){
    $output = mysqli_fetch_all($result, MYSQLI_ASSOC);

    echo json_encode($output);
}else{
    echo "No record found";
}
?>