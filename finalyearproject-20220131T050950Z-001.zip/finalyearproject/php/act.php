<?php

include 'dbcon.php';
$sql = "Select productname from categories";
$res=mysqli_query($con,$sql)or die("sql query failed");
if(mysqli_num_rows($res) > 0){
    $output = mysqli_fetch_all($res, MYSQLI_ASSOC);

    echo json_encode($output);
}else{
    echo "No record found";
}
    
?>