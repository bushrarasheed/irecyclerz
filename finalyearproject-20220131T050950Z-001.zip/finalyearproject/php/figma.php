<!DOCTYPE html>
<html lang="en">
<head>
<style>
 /* body {
    background-repeat: no-repeat;
    position: relative;
    width: 80%;
    height: auto;
    background-color: gray;
    margin: 0px;
    margin-left: 0px;
    margin-right: 0;
    padding-right: 0px;
 }   */
/* 
.logo {
    float: left;
    margin-top: 5px;
} */

/* .navbar {
    margin-bottom: 0px!important;
} */
/*  */

/*#myCarousel{
	margin-bottom:20px;
	margin-right:0px;
	width:1348px;
	height:600px;
	 margin-top:-100px;
	 padding-top:0px;

}*/

/* .carousel-inner .item {
    height: 100vh;
}

.carousel-inner .item img {
    width: 1500px;
}

.carousel-caption {
    padding-bottom: 200px;
    height: 500px;
}

.carousel-caption h2 {
    font-size: 50px;
    text-transform: uppercase;
}

.carousel-control.right {
    background-image: none;
}

.carousel-control.left {
    background-image: none;
}

.search-container {
    float: right;
    margin-right: 30px;
}

.search {
    padding: 6px;
    margin-top: 8px;
    font-size: 17px;
    border: none;
    border-radius: 8px;
}

.search-container button {
    float: right;
    padding: 6px 10px;
    margin-top: 8px;
    margin-right: 20px;
    background: transparent;
    font-size: 17px;
    border: none;
    cursor: pointer;
    border-radius: 8px;
}  */

.sec-2 {
    color: green;
    font-weight: bold;
    font-size: 30px;
    text-align: center;
    width: 1400px;
}

.h2-heading {
    padding-top:90px;
    color:green;
    
    
}

.content-box {
    position: relative;
    width: 1300px;
    height: 350px;
    margin: 210px auto;
    margin-top: 100px;
} 

 .box {
    position: relative;
    height: 200px;
    background-color: white;
    float: left;
    margin: 10px;
    box-sizing: border-box;
    border-radius: 10px;
    box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
} 

.sec-3 {
    color: green;
    font-weight: bold;
    font-size: 30px;
    text-align: center;
    width: 1342px;
    background-color: blue;
}

.sec-4 {
    color: green;
    font-weight: bold;
    font-size: 30px;
    text-align: center;
    width: 1342px;
}

 ::placeholder {
    font-size: 15px;
    text-align: left;
    color: #bec4c0;
} 

.about {
    color: gray;
    font-size: 30px;
    padding-top: 40px;
}

.about-text {
    font-size: 20px;
    color: gray;
    text-align: center;
    margin-top: 20px;
    padding-right: 250px;
    padding-left: 250px;
}

.thumbnail {
    box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}

.hz {
    padding-top: 30px;
    padding-bottom: 30px;
}

.sec {
    background-color: transparent;
} 

.boxes {
    position: relative;
    width: 500px;
    height: 200px;
    background-color: white;
    float: left;
    margin: 35px;
    box-sizing: border-box;
    border-radius: 10px;
    margin-left: 110px;
    box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
} 

.h4-heading{
    margin-top:35px;

}

/* .site-footer {
    background-color: #26272b;
    padding: 55px 0 20px;
    font-size: 15px;
    line-height: 24px;
    color: #737373;
}

.site-footer hr {
    border-top-color: #bbb;
    opacity: 0.5
}

.site-footer hr.small {
    margin: 20px 0
}

.site-footer h6 {
    color: #fff;
    font-size: 16px;
    text-transform: uppercase;
    margin-top: 5px;
    letter-spacing: 2px
}

.site-footer a {
    color: #737373;
}

.site-footer a:hover {
    color: #3366cc;
    text-decoration: none;
}

.footer-links {
    padding-left: 0;
    list-style: none
}

.footer-links li {
    display: block
}

.footer-links a {
    color: #737373
}

.footer-links a:active,
.footer-links a:focus,
.footer-links a:hover {
    color: #3366cc;
    text-decoration: none;
}

.footer-links.inline li {
    display: inline-block
}

.site-footer .social-icons {
    text-align: right
}

.site-footer .social-icons a {
    width: 40px;
    height: 40px;
    line-height: 40px;
    margin-left: 6px;
    margin-right: 0;
    border-radius: 100%;
    background-color: #33353d
}

.copyright-text {
    margin: 0
}

@media (max-width:991px) {
    .site-footer [class^=col-] {
        margin-bottom: 30px
    }
}

@media (max-width:767px) {
    .site-footer {
        padding-bottom: 0
    }
    .site-footer .copyright-text,
    .site-footer .social-icons {
        text-align: center
    }
}

.social-icons {
    padding-left: 0;
    margin-bottom: 0;
    list-style: none
}

.social-icons li {
    display: inline-block;
    margin-bottom: 4px
}

.social-icons li.title {
    margin-right: 15px;
    text-transform: uppercase;
    color: #96a2b2;
    font-weight: 700;
    font-size: 13px
}

.social-icons a {
    background-color: #eceeef;
    color: #818a91;
    font-size: 16px;
    display: inline-block;
    line-height: 44px;
    width: 44px;
    height: 44px;
    text-align: center;
    margin-right: 8px;
    border-radius: 100%;
    -webkit-transition: all .2s linear;
    -o-transition: all .2s linear;
    transition: all .2s linear
}

.social-icons a:active,
.social-icons a:focus,
.social-icons a:hover {
    color: #fff;
    background-color: #29aafe
}

.social-icons.size-sm a {
    line-height: 34px;
    height: 34px;
    width: 34px;
    font-size: 14px
}

.social-icons a.facebook:hover {
    background-color: #3b5998
}

.social-icons a.twitter:hover {
    background-color: #00aced
}

.social-icons a.linkedin:hover {
    background-color: #007bb6
}

.social-icons a.dribbble:hover {
    background-color: #ea4c89
}

@media (max-width:767px) {
    .social-icons li.title {
        display: block;
        margin-right: 0;
        font-weight: 600
    }
    .container {
        max-width: 400px;
        width: 100%;
        margin: 0 auto;
        position: relative;
    }
    #contact {
        background: #F9F9F9;
        padding: 25px;
        margin: 150px 0;
        box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
    }
    #contact h3 {
        display: block;
        font-size: 30px;
        font-weight: 300;
        margin-bottom: 10px;
    }
    #contact h4 {
        margin: 5px 0 15px;
        display: block;
        font-size: 13px;
        font-weight: 400;
    }
    fieldset {
        border: medium none !important;
        margin: 0 0 10px;
        min-width: 100%;
        padding: 0;
        width: 100%;
    }
    #contact textarea {
        height: 100px;
        max-width: 100%;
        resize: none;
    }
    #contact-submit {
        cursor: pointer;
        width: 100%;
        border: none;
        background: #4CAF50;
        color: #FFF;
        margin: 0 0 5px;
        padding: 10px;
        font-size: 15px;
    }
    .copyright {
        text-align: center;
    }
    #contact input:focus,
    #contact textarea:focus {
        outline: 0;
        border: 1px solid #aaa;
    }
     ::-webkit-input-placeholder {
        color: #888;
    }
     :-moz-placeholder {
        color: #888;
    }
     ::-moz-placeholder {
        color: #888;
    }
     :-ms-input-placeholder {
        color: #888;
    }
} */
</style>
</head>
</html>
