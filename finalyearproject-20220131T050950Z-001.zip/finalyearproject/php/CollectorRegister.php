<?php
session_start();



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" 
    integrity="sha512-PgQMlq+nqFLV4ylk1gwUOgm6CtIIXkKwaIHp/PAIWHzig/lKZSEGKEysh0TCVbHJXCLN7WetD8TFecIky75ZfQ==" crossorigin="anonymous" 
    referrerpolicy="no-referrer" />
  
    
    <link rel="stylesheet" type="text/css" href="../style2.css">
    <style>
        .type {
    margin-bottom: 30px;
    position: relative;
}

.type label {
    display: inline-block;
    margin-bottom: 5px;
}

.type input {
    width: 100%;
    border: 2px solid #f0f0f0;
    border-radius: 5px;
    display: block;
    font-family: var(--myfont);
    font-size: 14px;
    padding: 12px;
}
.type.success input {
    border-color: #2ecc71;
}
    </style>
</head>

<?php
    
include 'dbcon.php';    
   
if(isset($_POST['submit'])){
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $mobile =mysqli_real_escape_string($con, $_POST['mobile']);
    $password =mysqli_real_escape_string($con, $_POST['password']);
    $cpassword =mysqli_real_escape_string($con, $_POST['cpassword']);
    $cnic = mysqli_real_escape_string($con, $_POST['cnic']);
    $Role_type = mysqli_real_escape_string($con, $_POST['Role_type']);
    $company = mysqli_real_escape_string($con, $_POST['company']);
    
    
    $pass = password_hash($password, PASSWORD_BCRYPT);
    $cpass = password_hash($cpassword, PASSWORD_BCRYPT);

    $token = bin2hex(random_bytes(15));
    
    
    $emailquery = " Select * from registration where email='$email' ";
    $query = mysqli_query($con,$emailquery);
    
   
    $emailcount = mysqli_num_rows($query);
    $msg ="";
    if($emailcount>0){
        $msg ="Email already exist";
        ?>
        <script>
            alert("Email already exist");
            //$("#emailerr").text("Email already exist");
        </script>

    <?php
    }else{
        if($password === $cpassword){
            
            $insertquery = "insert into registration(username, email, mobile, password, cpassword,cnic,  token, Status,Role_type,company) values('$username','$email','$mobile','$pass','$cpass','$cnic','$token','inactive','$Role_type','$company')";
            
            
            $iquery = mysqli_query($con, $insertquery);
            $mess = "";
            if($iquery){
                
                
                

               $subject = "Email activation";
               $body = "Hi, $username.\n
               Click here too activate your account: \n
               http://localhost/finalyearproject/php/activate.php?token=$token \n";
                  
                  $message = '<html><body style="color:#f40;">';
                  $message .= '<img src="logo.png" alt="image" style="width: 100px; height:100px;"> ';               ;
                  $message .= '<p style="color:#080;font-size:18px;"></p>'.$body;
                  $message .= '</body></html>';

                  
                  $sender_email = "From: irecyclerz@gmail.com";
                  $from="irecyclerz@gmail.com";
                  
                  $header='';
                  $header .= 'MIME-Version: 1.0' . "\r\n";
                  $header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                  $header .= "From: $from \r\n" .
                        "Reply-To: $from \r\n" .
                        "X-Mailer: PHP/" . phpversion();
                  //if (mail($email, $subject, $body, $sender_email)) {
                     if (mail($email, $subject, $message, $header)) {
                     $_SESSION['msg'] = "check you mail to activate your account $email";
                     header('location:login.php');
                  } else {
                     echo "Email sending failed...";
                  }
            }else{
    
                ?>
                    <script>
                        alert("no inserted");

                    </script>
    
                <?php
            }



            
            
        }else{
           $mess = "password are not matching";
        }
    }
}
  
 ?> 
  
<body>

                 

<div class="container">
<div class="header">
<!-- <img src="logo.png"> -->
<h2>Registration</h2>
</div>
<form class="form "  id="form" method="post" onsubmit="return validateForm();">
<div class="row">
    <div class="col">
    <div class="type">
    <label>Role</label>
        <input readonly type="text" name="Role_type" id="Role_type" value="Waste_Collector" >
    </div>
   
    <div class="form-control">
        <label>Username</label>
        <input type="username" name="username" id="username" placeholder="Enter your name*" autocomplete="on">
        <i class="fas fa-check-circle"></i>
        <i class="fas fa-exclamation-circle"></i>
        <small>Error Msg</small>
    </div>
    <div class="form-control">
        <label>Email</label>
        <input type="email" name="email" id="email" placeholder="Enter your email*"autocomplete="on">
        <i class="fas fa-check-circle"></i>
        <i class="fas fa-exclamation-circle"></i>
        <small>Error Msg</small>
    </div>
    <div class="form-control">
        <label>CNIC</label>
        <input type="text" name="cnic" id="cnic" placeholder="Enter your cnic*"autocomplete="on">
        <i class="fas fa-check-circle"></i>
        <i class="fas fa-exclamation-circle"></i>
        <small>Error Msg</small>
    </div>
   
</div>
    <div class="col">
    <div class="form-control">
        <label>Mobile Number</label>
        <input type="text" name="mobile" id="phone" placeholder="Enter your mobile number*"autocomplete="on">
        <i class="fas fa-check-circle"></i>
        <i class="fas fa-exclamation-circle"></i>
        <small>Error Msg</small>
    </div>
    <div class="form-control">
        <label>Password</label>
        <input type="password" name="password" id="password" placeholder="Enter your password*"autocomplete="on">
        <i class="fas fa-check-circle"></i>
        <i class="fas fa-exclamation-circle"></i>
        <small>Error Msg</small>
    </div>
    <div class="form-control">
        <label>Confirm Password</label>
        <input type="password" name="cpassword" id="cpassword" placeholder="Enter your confirm password*"autocomplete="on">
        <span  class="text-danger font-weight-bold"><?=$mess;?></span>  
        <i class="fas fa-check-circle"></i>
        <i class="fas fa-exclamation-circle"></i>
        <small>Error Msg</small>
    </div>
    <div class="form-control">
        <label>Recycling Company</label>
        <select class="form-select" type="company" name="company" id="company" require >
            <option selected>Recycling Companies</option>
            <option value="FARSA">FARSA</option>
            <option value="Alico">Alico</option>
            <option value="Pak Recycling">Pak Recycling</option>
            
        </select>
        <span  class="text-danger font-weight-bold"><?=$mess;?></span>  
        <i class="fas fa-check-circle"></i>
        <i class="fas fa-exclamation-circle"></i>
        <small>Error Msg</small>
    </div>
    
   
    </div>
</div>
<!-- <button  type="submit" value="Submit" name="submit" class="btn btn-block text-center">Submit</button> -->
    <input type="submit" value="Submit" class="btn" name="submit">
    <p style="text-align: center;">Have an account? <a href="login.php" class="text-info">Log in</a></p>
</form>
</div>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script type="text/javascript">
    const form = document.getElementById('form');
    const username = document.getElementById('username');
    const email = document.getElementById('email');
    const phone = document.getElementById('phone');
    const password = document.getElementById('password');
    const cpassword = document.getElementById('cpassword');
    const cnic = document.getElementById('cnic');
    const address = document.getElementById('address');

    //addevent

    // form.addEventListener('submit', (event) => {
    //     event.preventDefault();
        
    //     Validate();

    // });
    function validateForm()
    {
        if (Validate()) {
            return true;
            swal("Welcome"+usernameVal, "You clicked the button!", "success");
        }else{
            return false;
        }
    }
    const sendData = (usernameVal, sRate, count) =>{
        if(sRate === count){
            // alert('registration successfull');
             swal("Welcome"+usernameVal , "You clicked the button!", "success");
             location.href = 'demo.html?username=${usernameVal}'
            
        }
    }
    //for final data validation
    const Successmsg = (usernameVal) =>{
        let formCon = document.getElementsByClassName('form-control ');
        var count = formCon.length - 1;
        for(var i = 0 ; i < formCon.length; i++){
            if(formCon[i].className === "form-control success"){
                var sRate = 0 + i;
                console.log(sRate);
                sendData(usernameVal, sRate, count);
            }else{
                return false;
            }
        }
    }


    //more email validate

    const isEmail = (emailVal) => {
        var atSymbol = emailVal.indexOf("@");
        if(atSymbol < 1) return false;
        var dot = emailVal.lastIndexOf(".");
        if(dot <= atSymbol + 2)return false;
        if(dot === emailVal.lenght - 1)return false;
        return true;
    }

    //validate function

    const Validate = () =>{
        
        const usernameVal = username.value.trim();
        const emailVal = email.value.trim();
        const phoneVal = phone.value.trim();
        const passwordVal = password.value.trim();
        const cpasswordVal = cpassword.value.trim();
        const cnicVal = cnic.value.trim();
        const addressVal = address.value.trim();
        const passwordcheck = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/;
        const phonecheck = /^[+92][0-9]{9}[0-9]{3}$/;
        const cniccheck  = /^([0-9]{5})[-]([0-9]{7})[-]([0-9]{1})$/;
        const usernamecheck = /^[A-Za-z. ]{3,30}$/;
     var err=0;
        //user valid
        if(usernameVal === ""){
            setErrormsg(username, 'username cannot be blank');
            err++;
            
        }
        else if(!usernameVal.match(usernamecheck)){
            setErrormsg(username, 'Use only character');
            err++;
        }
        else{
            setSuccessmsg(username);
        }

        //email

        if(emailVal === ""){
            setErrormsg(email, 'Email cannot be blank');
            
        }
        else if(!isEmail(emailVal)){
            setErrormsg(email, 'Not a valid');
        }
        else{
            setSuccessmsg(email);
        }
        
    

    //phone

    
    if(phoneVal === ""){
            setErrormsg(phone, 'Phone cannot be blank');
            
        }
        else if(!phoneVal.match(phonecheck)){
            setErrormsg(phone, 'Not a valid phone number');
        }
        else{
            setSuccessmsg(phone);
        }
        
    //password    
        if(passwordVal === ""){
            setErrormsg(password, 'Password conot be null');
            
        }
        else if(!passwordVal.match(passwordcheck)){
            setErrormsg(password, 'inValid password');
        }
        else{
            setSuccessmsg(password);
        }

    //password    
    if(cpasswordVal === ""){
            setErrormsg(cpassword, 'Confirm Password conot be null');
            
        }
        else if(!cpasswordVal.match(passwordcheck) ){
            setErrormsg(cpassword, 'password must conatin special chacrater and number');
        }
        else{
            setSuccessmsg(cpassword);
        }
    //Cnic
        if(cnicVal === ""){
            setErrormsg(cnic, 'CNIC conot be null');
            
        }
        else if(!cnicVal.match(cniccheck)){
            setErrormsg(cnic, 'Cnic doesnot match');
        }
        else{
            setSuccessmsg(cnic);
        }


        //Address
        if(addressVal === ""){
            setErrormsg(address, ' Address conot be null');
            
        }
        else if(addressVal.length <= 5){
            setErrormsg(address, 'Minimum 6 characterNot a valid phone number');
        }
        else{
            setSuccessmsg(address);
        }
        Successmsg(usernameVal);
        if(err > 0)
            return false;
        else
       
                                       
            return true;
    }


    function setErrormsg(input, errormsgs) {
        const formControl = input.parentElement;
        const small = formControl.querySelector('small');
        formControl.className = "form-control error";
        small.innerText = errormsgs;
        
    }

    function setSuccessmsg(input) {
        const formControl = input.parentElement;
       
        formControl.className = "form-control success";
    }
    
    

</script>

    
</body>
    

</html>