<?php
session_start();



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" 
    integrity="sha512-PgQMlq+nqFLV4ylk1gwUOgm6CtIIXkKwaIHp/PAIWHzig/lKZSEGKEysh0TCVbHJXCLN7WetD8TFecIky75ZfQ==" crossorigin="anonymous" 
    referrerpolicy="no-referrer" />
  
    
    <link rel="stylesheet" type="text/css" href="../style2.css">
    <style>
        .type {
    margin-bottom: 30px;
    position: relative;
}

.type label {
    display: inline-block;
    margin-bottom: 5px;
    
}

.type input {
    width: 100%;
    border: 2px solid #f0f0f0;
    border-radius: 5px;
    display: block;
    font-family: var(--myfont);
    font-size: 14px;
    padding: 12px;
}
.type.success input {
    border-color: #2ecc71;
}
    </style>
</head>

<?php
  include 'dbcon.php';
    
    if(isset($_POST['submit'])){
        $email = $_POST['email'];
        $password =$_POST['password'];
        
        $email_search = "select * from registration where email = '$email' and Status='active' ";
        $query = mysqli_query($con,$email_search);     
        $email_count = mysqli_num_rows($query);        
        if($email_count){
            $email_pass = mysqli_fetch_assoc($query);
            
            $db_pass = $email_pass['password'];
            $_SESSION['id'] = $email_pass['id'];
            $_SESSION['username'] = $email_pass['username'];  
            $_SESSION['location'] = $email_pass['location'];
            $_SESSION['email'] = $email_pass['email'];
            $_SESSION['Role_type'] = $email_pass['Role_type'];
            $_SESSION ['u_auth'] = 10;

            
            
            $pass_decode = password_verify($password,$db_pass);
            $msg="";
            if($pass_decode){
                echo "login sucessful";
                ?>
                
            
                <script>
                    location.replace("../Home.php");
    
                </script>
                

                
              <?php
            
            // $id_search = "SELECT id FROM registration where email = '$email'";
                            

            // $query = mysqli_query($con,$id_search);
            // $id_select = mysqli_fetch_assoc($query);
            // $_SESSION['id'] = $id_select["id"];
            // echo $_SESSION['id'];
                
            }else{
                $msg = "password incorrect";
                // echo "password in correct";
            }
            
        }
        
        else{
            echo "invalid email";
        }
    }
  
  ?>
  
<body>

                 

<div class="container">
<div class="header">
<!-- <img src="logo.png">  -->
<h2 >Login</h2><br><br>
</div>

                
            
                <p   style="text-align: center; background-color:green; height: 20%;">
                <?php 
                    if(isset($_SESSION['msg'])){
                        echo $_SESSION['msg'] ;
                    }else{
                        echo $_SESSION['msg'] = "You are logged out please login again";
                    }
                
                ?></p>
<form class="form "  id="form" method="post" onsubmit="return validateForm();" style="width:70%; margin-left:17%;">

    
    <div class="form-control" >
        <label>Email</label>
        <input type="email" name="email" id="email" placeholder="Enter your email*"autocomplete="on">
       
    </div>
   

    
    <div class="form-control">
        <label>Password</label>
        <input type="password" name="password" id="password" placeholder="Enter your password*"autocomplete="on">
        <span  class="text-danger font-weight-bold"><?=$msg;?></span>  
					
        
    </div>
   

<!-- <button  type="submit" value="Submit" name="submit" class="btn btn-block text-center">Submit</button> -->
    <input type="submit" value="Submit" class="btn" name="submit">
    <p style="text-align: center;">create an account <a href="register.php" class="text-info">Signup</a></p>
</form>
</div>

<!-- <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script type="text/javascript">
    const form = document.getElementById('form');
    const username = document.getElementById('username');
    const email = document.getElementById('email');
    const phone = document.getElementById('phone');
    const password = document.getElementById('password');
    const cpassword = document.getElementById('cpassword');
    const cnic = document.getElementById('cnic');
    const address = document.getElementById('address');

    //addevent

    // form.addEventListener('submit', (event) => {
    //     event.preventDefault();
        
    //     Validate();

    // });
    function validateForm()
    {
        if (Validate()) {
            return true;
            swal("Welcome"+usernameVal, "You clicked the button!", "success");
        }else{
            return false;
        }
    }
    const sendData = (usernameVal, sRate, count) =>{
        if(sRate === count){
            // alert('registration successfull');
             swal("Welcome"+usernameVal , "You clicked the button!", "success");
             location.href = 'demo.html?username=${usernameVal}'
            
        }
    }
    //for final data validation
    const Successmsg = (usernameVal) =>{
        let formCon = document.getElementsByClassName('form-control ');
        var count = formCon.length - 1;
        for(var i = 0 ; i < formCon.length; i++){
            if(formCon[i].className === "form-control success"){
                var sRate = 0 + i;
                console.log(sRate);
                sendData(usernameVal, sRate, count);
            }else{
                return false;
            }
        }
    }


    //more email validate

    const isEmail = (emailVal) => {
        var atSymbol = emailVal.indexOf("@");
        if(atSymbol < 1) return false;
        var dot = emailVal.lastIndexOf(".");
        if(dot <= atSymbol + 2)return false;
        if(dot === emailVal.lenght - 1)return false;
        return true;
    }

    //validate function

    const Validate = () =>{
        
        const usernameVal = username.value.trim();
        const emailVal = email.value.trim();
        const phoneVal = phone.value.trim();
        const passwordVal = password.value.trim();
        const cpasswordVal = cpassword.value.trim();
        const cnicVal = cnic.value.trim();
        const addressVal = address.value.trim();
        const passwordcheck = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/;
        const phonecheck = /^[+92][0-9]{9}[0-9]{3}$/;
        const cniccheck  = /^([0-9]{5})[-]([0-9]{7})[-]([0-9]{1})$/;
        const usernamecheck = /^[A-Za-z. ]{3,30}$/;
     var err=0;
        //user valid
        if(usernameVal === ""){
            setErrormsg(username, 'username cannot be blank');
            err++;
            
        }
        else if(!usernameVal.match(usernamecheck)){
            setErrormsg(username, 'Use only character');
            err++;
        }
        else{
            setSuccessmsg(username);
        }

        //email

        if(emailVal === ""){
            setErrormsg(email, 'Email cannot be blank');
            
        }
        else if(!isEmail(emailVal)){
            setErrormsg(email, 'Not a valid');
        }
        else{
            setSuccessmsg(email);
        }
        
    

    //phone

    
    if(phoneVal === ""){
            setErrormsg(phone, 'Phone cannot be blank');
            
        }
        else if(!phoneVal.match(phonecheck)){
            setErrormsg(phone, 'Not a valid phone number');
        }
        else{
            setSuccessmsg(phone);
        }
        
    //password    
        if(passwordVal === ""){
            setErrormsg(password, 'Password conot be null');
            
        }
        else if(!passwordVal.match(passwordcheck)){
            setErrormsg(password, 'inValid password');
        }
        else{
            setSuccessmsg(password);
        }

    //password    
    if(cpasswordVal === ""){
            setErrormsg(cpassword, 'Confirm Password conot be null');
            
        }
        else if(!cpasswordVal.match(passwordcheck) ){
            setErrormsg(cpassword, 'password must conatin special chacrater and number');
        }
        else{
            setSuccessmsg(cpassword);
        }
    //Cnic
        if(cnicVal === ""){
            setErrormsg(cnic, 'CNIC conot be null');
            
        }
        else if(!cnicVal.match(cniccheck)){
            setErrormsg(cnic, 'Cnic doesnot match');
        }
        else{
            setSuccessmsg(cnic);
        }


        //Address
        if(addressVal === ""){
            setErrormsg(address, ' Address conot be null');
            
        }
        else if(addressVal.length <= 5){
            setErrormsg(address, 'Minimum 6 characterNot a valid phone number');
        }
        else{
            setSuccessmsg(address);
        }
        Successmsg(usernameVal);
        if(err > 0)
            return false;
        else
       
                                       
            return true;
    }


    function setErrormsg(input, errormsgs) {
        const formControl = input.parentElement;
        const small = formControl.querySelector('small');
        formControl.className = "form-control error";
        small.innerText = errormsgs;
        
    }

    function setSuccessmsg(input) {
        const formControl = input.parentElement;
       
        formControl.className = "form-control success";
    }
    
    

</script> -->

    
</body>
    

</html>