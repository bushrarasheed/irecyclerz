<?php 
include 'dbcon.php';
if(session_status() == PHP_SESSION_NONE)
{
	session_start();//start session if session not start
}


?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>iRecyclerz</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon"  href="../image/logo.jpg">

    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../stylefyp.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
</head>

 
<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <header id="htc__header" class="htc__header__area header--one">
            <!-- Start Mainmenu Area -->
            <div id="sticky-header-with-topbar" class="mainmenu__wrap sticky__header">
                <div class="container">
                    <div class="row">
                        <div class="menumenu__container clearfix">
                            <div class="col-lg-2 col-md-2 col-sm-3 col-xs-5"> 
                                <div class="logo">
                                     <a href="index.html"><img src="../image/logo.png" height="80px;" alt="logo images"></a>
                                </div>
                            </div>

                           <!---------------- nave list item----------->
                            <div class="col-md-7 col-lg-8 col-sm-5 col-xs-3">
                                <nav class="main__menu__nav hidden-xs hidden-sm">
                                    <ul class="main__menu">
                                        <li class="drop"><a href="../Home.php"><b>Home</b></a></li>
                                        <li class="drop"><a href="About.php"><b>About</b></a></li>
                                            <!-- <ul class="dropdown mega_dropdown">  -->
                                                <!-- Start Single Mega MEnu -->
                                                <!-- <li><a class="mega__title" href="Services.php"><b>Services</b></a>
                                                    <ul class="mega__item">
                                                        <li><a href="product-grid.html">Product Grid</a></li>
                                                        <li><a href="cart.html">cart</a></li>
                                                        <li><a href="checkout.html">checkout</a></li>
                                                        <li><a href="wishlist.html">wishlist</a></li>
                                                    </ul> -->
                                                <!-- </li> -->
                                                <!-- End Single Mega MEnu -->
                                                <!-- Start Single Mega MEnu -->
                                                <!-- <li><a class="mega__title" href="product-grid.html">Variable Product</a>
                                                    <ul class="mega__item">
                                                        <li><a href="#">Category</a></li>
                                                        <li><a href="#">My Account</a></li>
                                                        <li><a href="wishlist.html">Wishlist</a></li>
                                                        <li><a href="cart.html">Shopping Cart</a></li>
                                                        <li><a href="checkout.html">Checkout</a></li>
                                                    </ul>
                                                </li> -->
                                                <!-- End Single Mega MEnu -->
                                                <!-- Start Single Mega MEnu -->
                                                <!-- <li><a class="mega__title" href="product-grid.html">Product Types</a>
                                                    <ul class="mega__item">
                                                        <li><a href="#">Simple Product</a></li>
                                                        <li><a href="#">Variable Product</a></li>
                                                        <li><a href="#">Grouped Product</a></li>
                                                        <li><a href="#">Downloadable Product</a></li>
                                                        <li><a href="#">Simple Product</a></li>
                                                    </ul>
                                                </li> -->
                                                <!-- End Single Mega MEnu -->
                                           
                                        <li class="drop"><a href="service.php"><b>Services</b></a>
                                                   
                                        </li>
                                          
                                        <li class="drop"><a href="contact.php"><b>Contact us</b></a>
                                           
                                        </li>
                                       
                                        <li class="drop"><a href="#"><b>Signup</b></a>
                                            <ul class="dropdown">
                                                <li><a href="Registration.php">Waste collector</a></li>
                                                <li><a href="Registration.php">Waste Producer</a></li>
                                                
                                            </ul>
                                        </li>
                                        <li class="drop"><a href="logout.php"><b>Logout</b></a>
                                        
                                        </li>
                                        <li  style="margin-top: 30px; font-size:150%; padding-left:9em; margin-right:-50%;"><b><?php  echo $_SESSION['username'];  ?></b>
                                         
                                       
                                            
                                        </li>
                                 
                                   
                                    </ul>
                                </nav>

                                <div class="mobile-menu clearfix visible-xs visible-sm">
                                    <nav id="mobile_dropdown">
                                        <ul>
                                            <li><a href="../Home.php">Home</a></li>
                                            <li><a href="About.php">About</a></li>
                                            <li><a href="service.php">Service</a>
                                                <!-- <ul>
                                                    <li><a href="blog.html">Blog</a></li>
                                                    <li><a href="blog-details.html">Blog Details</a></li>
                                                    <li><a href="cart.html">Cart page</a></li>
                                                    <li><a href="checkout.html">checkout</a></li>
                                                    <li><a href="contact.html">contact</a></li>
                                                    <li><a href="product-grid.html">product grid</a></li>
                                                    <li><a href="product-details.html">product details</a></li>
                                                    <li><a href="wishlist.html">wishlist</a></li>
                                                </ul> -->
                                            </li>
                                            <li><a href="contact.html">contact</a></li>
                                            <li><a href="service.php">Signup</a>
                                                 <ul>
                                                    <li><a href="Registration.php">Waste Producer</a></li>
                                                    <li><a href="CollectorRegister.php">Waste Collector</a></li>
                                                   
                                                </ul> 
                                            </li>
                                            <li class="drop"><a href="logout.php"><b>Logout</b></a>
                                        
                                        </li>
                                        <li  style="margin-top: 30px; font-size:150%; padding-left:9em; margin-right:-50%;"><b><?php  echo $_SESSION['username'];  ?></b>
                                         
                                       
                                            
                                        </li>
                                        </ul>
                                    </nav>
                                </div>  
                            </div>
                            <!-- <div class="col-md-3 col-lg-2 col-sm-4 col-xs-4">
                                <div class="header__right">
                                    <div class="header__search search search__open">
                                        <a href="#"><i class="icon-magnifier icons"></i></a>
                                    </div> -->
                                 <!-------------------account--------------------->

                                <!----yhan se htaya he cart view icon---->
                                <!-- </div>
                            </div> -->
                        </div>
                    </div>
                    <div class="mobile-menu-area"></div>
                </div>
            </div>
            <!-- End Mainmenu Area -->
        </header>
        <!-- End Header Area -->

        <div class="body__overlay"></div>
        <!-- Start Offset Wrapper -->
        <div class="offset__wrapper">
            <!-- Start Search Popap -->
            <div class="search__area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="search__inner">
                                <form action="#" method="get">
                                    <input placeholder="Search here... " type="text">
                                    <button type="submit"></button>
                                </form>
                                <div class="search__close__btn">
                                    <span class="search__close__btn_icon"><i class="zmdi zmdi-close"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Search Popap -->
            <!-- Start Cart Panel -->
            <div class="shopping__cart">
                <div class="shopping__cart__inner">
                    <div class="offsetmenu__close__btn">
                        <a href="#"><i class="zmdi zmdi-close"></i></a>
                    </div>
                    <div class="shp__cart__wrap">
                        <div class="shp__single__product">
                            <div class="shp__pro__thumb">
                                <a href="#">
                                    <img src="" alt="product images">
                                </a>
                            </div>
                            <div class="shp__pro__details">
                                <h2><a href="product-details.html">BO&Play Wireless Speaker</a></h2>
                                <span class="quantity">QTY: 1</span>
                                <span class="shp__price">$105.00</span>
                            </div>
                            <div class="remove__btn">
                                <a href="#" title="Remove this item"><i class="zmdi zmdi-close"></i></a>
                            </div>
                        </div>
                        <div class="shp__single__product">
                            <div class="shp__pro__thumb">
                                <a href="#">
                                    <img src="" alt="product images">
                                </a>
                            </div>
                            <div class="shp__pro__details">
                                <h2><a href="product-details.html">Brone Candle</a></h2>
                                <span class="quantity">QTY: 1</span>
                                <span class="shp__price">$25.00</span>
                            </div>
                            <div class="remove__btn">
                                <a href="#" title="Remove this item"><i class="zmdi zmdi-close"></i></a>
                            </div>
                        </div>
                    </div>
                    <ul class="shoping__total">
                        <li class="subtotal">Subtotal:</li>
                        <li class="total__price">$130.00</li>
                    </ul>
                    <ul class="shopping__btn">
                        <li><a href="cart.html">View Cart</a></li>
                        <li class="shp__checkout"><a href="checkout.html">Checkout</a></li>
                    </ul>
                </div>
            </div>
            <!-- End Cart Panel -->
        </div>
        <!-- End Offset Wrapper -->
        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area" style="background: linear-gradient(rgba(0, 0, 0, 0.527),rgba(0, 0, 0, 0.5)) , url(../image/waste-bins-3119669_1920.jpg) no-repeat scroll center center;width: 100%; height:20%;">
            
            <div class="ht__bradcaump__wrap">
                <div class="container">

                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner">
                                <nav class="bradcaump-inner">
                                <?php 
                                    include 'dbcon.php';
                                    $id = $_GET['cat_id'];
                                    //echo $id;
                                    $sql = "Select productname  from `categories` WHERE  id = $id limit 1";
                                    $run = mysqli_query($con,$sql);
                                    if (mysqli_num_rows($run) > 0) {
                                        $output = mysqli_fetch_array($run); 
                                        ?>
                                    
                                   
                                    <b><h2 style="font-size:500%; color:white;">SERVICE-FORM</h2></b><br>
                                    <b><h3 style="font-size:400%; color:white;"><?=$output['productname']; ?></h3></b>
                                    <span class="brd-separetor"></span>
                                    <?php
                                    }else{
                                        echo '';
                                    }
                                    ?>


                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <!-- Start Contact Area -->
        <div class="container-fluid">
	<div class="col-md-1"></div>
	<div class="col-md-10">
		<div class="panel panel-danger">
			<div class="panel-heading">
				<h3 class="panel-title">STEPS FOR SERVICES</h3>
			</div>
			<div class="panel-body">
				<div class="row">
					<div class="col-md-3">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h3 class="panel-title">1. Step
								</h3>
							</div>
							<div class="panel-body">
                                SCHEDULE FOR SERVICE
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="panel panel-info">
							<div class="panel-heading">
								<h3 class="panel-title">2. Type of Garbage
								<span class="glyphicon glyphicon-saved" aria-hidden="true"></span>
								</h3>
							</div>
							<div class="panel-body">
                                GARBAGE TYPE
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="panel panel-success">
							<div class="panel-heading">
								<h3 class="panel-title">3. USER INFO</h3>
							</div>
							<div class="panel-body">
                                USERS DETAILS
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="panel panel-warning">
							<div class="panel-heading">
								<h3 class="panel-title">4. PAYMENT INFO</h3>
							</div>
							<div class="panel-body">
								TOTAL PAYMENT
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-1"></div>
</div>


<div class="container-fluid">
	<div class="col-md-3"></div>
	<div class="col-md-6">
		<div class="panel panel-default">
			<div class="panel-body">
			 <h2>
			 	<center>TYPES OF GARBAGE</center>
			 </h2>
				<div class="container-fluid">
					<form class="form-horizontal" role="form" id="form-acc" method="POST">
                    <div class="form-group" style="width: 100%; margin-left:0%;">
					    <label for="">Type:</label>
					    <select class="btn btn-default" id="garbagetype" >
                        <option value="">SELECT GARBAGE TYPE</option>
					    </select>
					  </div>
                      <div class="form-group" style="width: 100%; margin-left:0%;">
                            <label for="">Price</label>
                            <input type="text" class="form-control" name="Priceperkg" value="" plactreholder="Price" id="priceperkg" autocomplete="off" readonly>
                            </div>
                           
                                 
						    <label for="">Weight</label>
                            <div class="input-group" style="width: 100%; ">
                            
                            
                            <input type="number" min="5" id="weight" class="form-control" name="weight" value="" plactreholder="Weight" autocomplete="off" >
                            <span class="input-group-addon">Kg</span>

                            <input type="hidden" class="form-control" name="type_id" value="" plactreholder="id" id="type_id" autocomplete="off" >
                            
                            </div><br/>
				      
					    <button type="submit" name="submit" class="btn btn-success" >NEXT
					    <span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span>
					  </button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-3"></div>
</div>
        <!-- End Contact Area -->
        <!-- End Banner Area -->
        <!-- Start Footer Area -->
        <footer id="htc__footer">
            <!-- Start Footer Widget -->
            <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">ABOUT US</h2>
                                <div class="ft__details">
                                    <p>Make Request to make your service done.We will be pleased to accept your request and will definetly try to complete the requested service accoplished to make your environment safe.The recovery of energy 
from waste materials is often included in this concept.Make Request to make your service done.We will be pleased to accept your request and will definetly try to complete the requested service accoplished to make your environment safe.</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Categories</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Waste Producer</a></li>
                                        <li><a href="#">Waste Collector</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Sub Categories</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Hazard</a></li>
                                        <li><a href="cart.html">Non Hazard</a></li>
                                      
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Quik link</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">About us</a></li>
                                        <li><a href="cart.html">Contact us</a></li>
                                        <li><a href="#">Login</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Address</h2>
                                <a><p>Jinnah university for women
                                       5-c Nazimabad,karachi</p></a><br>
                                <div class="ft__inner">
                                <h2 class="title__line--2">Phone</h2>
                                    <ul class="ft__list">
                                   
              <li><a href="http://scanfcode.com/sitemap/">034-5894562</a></li>

              <li><a href="http://scanfcode.com/sitemap/">034-5894562</a></li>

              <li><a href="http://scanfcode.com/sitemap/">034-5894562</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                     
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
            </div>
            <!-- End Footer Widget -->
            <!-- Start Copyright Area -->
            <div class="htc__copyright bg__cat--5">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="copyright__inner">
                                <p>Copyright© <a href="https://freethemescloud.com/">Free themes Cloud</a> 2018. All right reserved.</p>
                                <a href="#"><img src="" alt="payment images"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copyright Area -->
        </footer>
        <!-- End Footer Style -->
    </div>
    <!-- Body main wrapper end -->

    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- jquery latest version -->
    <script src="js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="js/plugins.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="js/main.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <!-- <script src="js/main.js"></script> -->
<!-- <script>
    $(document).on("change","input[type=radio]",function(){
    var ac=$('[name="type_name"]:checked').val();
    alert(ac);

    
});
</script> -->
  
<script type="text/javascript">
	$(document).on('submit', '#form-acc', function(event) {
		event.preventDefault();
		/* Act on the event */
		var typ = $('select[id=garbagetype]').val();
        var wei = $('input[id=weight]').val();
        var Priceperkg = $('input[id=priceperkg]').val();
        var type_id = $('input[id=type_id ]').val();
	    //alert(typ);

		if(typ == null){
			alert('Please Select Garbage Type!');
		}else{
			// console.log(acc);
			if(weight.length == 0){
				alert('Please Enter Weight Of Garbage!');
			}
            else{
				$.ajax({
						url: 'get_type.php',
						type: 'post',
						dataType: 'json',
						data: {
							typ : typ,
                            wei : wei,
                            Priceperkg: Priceperkg,
                            type_id:type_id,
                            //cat_id=<?//=$_REQUEST['cat_id'];?>,
							
						},
						success: function (data) {
						//console.log(data);
                        //alert(data);
						if(data.valid == true){
							//window.location = data.url;
                            window.location="user.php?cat_id=<?=$_REQUEST['cat_id'];?>";
							console.log('sss');
						}
					},
						error: function(){
							alert('Error: L175+');
						}
					});
			}//end totalPass
		}//end acc == null
	});

</script>
<script>
    $(document).ready(function(){
       
            $.ajax({
                url:"load_data.php",
                type: "POST",
                data:{cat_id:'<?=$_REQUEST['cat_id'];?>'},
                dataType: "JSON",
                success: function (data){
                        $.each(data, function(key, value){
                            // '<input type="radio" value="'+ value.type_name +'" id="'+ i +'"/>'
                            $("#garbagetype").append("<option value'" + value.type_name + "'>" + value.type_name + "</option>");
                        });
                    }
            });
            $("#garbagetype").change(function(){
                var type_name = $(this).val();
               
                if(type_name == ""){
                    $("#priceperkg").html("");
                    
                    
                }else{
                    $.ajax({
                        url:"load_table.php",
                        type: "POST",
                        data: { type_name : type_name,
                          },
                        success: function(data){
                            var obj = jQuery.parseJSON(data);
                            console.log(obj.typeID);
                            
                            $("#priceperkg").val(obj.output);  
                            $("#type_id").val(obj.typeID);  
                             
                           
                        }
                    });

                }
               
                

            });
            
        
    });
</script>

</body>

</html>