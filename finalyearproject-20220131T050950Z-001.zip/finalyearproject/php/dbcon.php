<?php
$server = "localhost";
$user = "root";
$password = "";
$db = "fyp_2018";

$con = mysqli_connect($server,$user,$password,$db);


   
 ?>

  





