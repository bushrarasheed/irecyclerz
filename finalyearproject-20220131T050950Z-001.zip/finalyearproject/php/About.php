<?php
include "dbcon.php";
if(session_status() == PHP_SESSION_NONE)
{
	session_start();//start session if session not start
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>About</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon"  href="../image/logo.jpg">
    

    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">
    <link rel="stylesheet" type="text/css" href="../about.css">
    <link rel="stylesheet" type="text/css" href="../service_form.css">
    <?php include 'figma.php'?>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->  

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <header id="htc__header" class="htc__header__area header--one">
            <!-- Start Mainmenu Area -->
            <div id="sticky-header-with-topbar" class="mainmenu__wrap sticky__header">
                <div class="container">
                    <div class="row">
                        <div class="menumenu__container clearfix">
                            <div class="col-lg-2 col-md-2 col-sm-3 col-xs-5"> 
                                <div class="logo">
                                     <a href="index.html"><img src="../image/logo.png" height="80px;" alt="logo images"></a>
                                </div>
                            </div>

                           <!---------------- nave list item----------->
                            <div class="col-md-7 col-lg-8 col-sm-5 col-xs-3">
                                <nav class="main__menu__nav hidden-xs hidden-sm">
                                    <ul class="main__menu">
                                        <li class="drop"><a href="../Home.php"><b>Home</b></a></li>
                                        <li class="drop"><a href="About.php"><b>About</b></a></li>
                                            <!-- <ul class="dropdown mega_dropdown">  -->
                                                <!-- Start Single Mega MEnu -->
                                                <!-- <li><a class="mega__title" href="Services.php"><b>Services</b></a>
                                                    <ul class="mega__item">
                                                        <li><a href="product-grid.html">Product Grid</a></li>
                                                        <li><a href="cart.html">cart</a></li>
                                                        <li><a href="checkout.html">checkout</a></li>
                                                        <li><a href="wishlist.html">wishlist</a></li>
                                                    </ul> -->
                                                <!-- </li> -->
                                                <!-- End Single Mega MEnu -->
                                                <!-- Start Single Mega MEnu -->
                                                <!-- <li><a class="mega__title" href="product-grid.html">Variable Product</a>
                                                    <ul class="mega__item">
                                                        <li><a href="#">Category</a></li>
                                                        <li><a href="#">My Account</a></li>
                                                        <li><a href="wishlist.html">Wishlist</a></li>
                                                        <li><a href="cart.html">Shopping Cart</a></li>
                                                        <li><a href="checkout.html">Checkout</a></li>
                                                    </ul>
                                                </li> -->
                                                <!-- End Single Mega MEnu -->
                                                <!-- Start Single Mega MEnu -->
                                                <!-- <li><a class="mega__title" href="product-grid.html">Product Types</a>
                                                    <ul class="mega__item">
                                                        <li><a href="#">Simple Product</a></li>
                                                        <li><a href="#">Variable Product</a></li>
                                                        <li><a href="#">Grouped Product</a></li>
                                                        <li><a href="#">Downloadable Product</a></li>
                                                        <li><a href="#">Simple Product</a></li>
                                                    </ul>
                                                </li> -->
                                                <!-- End Single Mega MEnu -->
                                           
                                        <li class="drop"><a href="service.php"><b>Services</b></a>
                                                    <!--  -->
                                        </li>
                                          
                                        <li class="drop"><a href="contact.php"><b>Contact us</b></a>
                                           
                                        </li>
                                       
                                        <li class="drop"><a href="#"><b>Signup</b></a>
                                            <ul class="dropdown">
                                                    <li><a href="Registration.php">Waste Producer</a></li>
                                                    <li><a href="CollectorRegister.php">Waste Collector</a></li>
                                                
                                            </ul>
                                        </li>
                                        <li  style="margin-top: 30px; font-size:150%; padding-left:9em; margin-right:-50%;"><b><?php  echo $_SESSION['username'];  ?></b>
                                         
                                       
                                            
                                         </li>
                                         
                                   
                                    </ul>
                                </nav>

                                <div class="mobile-menu clearfix visible-xs visible-sm">
                                    <nav id="mobile_dropdown">
                                        <ul>
                                            <li><a href="Home.php">Home</a></li>
                                            <li><a href="About.php">About</a></li>
                                            <li><a href="service.php">Service</a>
                                                <!-- <ul>
                                                    <li><a href="blog.html">Blog</a></li>
                                                    <li><a href="blog-details.html">Blog Details</a></li>
                                                    <li><a href="cart.html">Cart page</a></li>
                                                    <li><a href="checkout.html">checkout</a></li>
                                                    <li><a href="contact.html">contact</a></li>
                                                    <li><a href="product-grid.html">product grid</a></li>
                                                    <li><a href="product-details.html">product details</a></li>
                                                    <li><a href="wishlist.html">wishlist</a></li>
                                                </ul> -->
                                            </li>
                                            <li><a href="contact.html">contact</a></li>
                                            <li><a href="service.php">Signup</a>
                                                 <ul>
                                                    <li><a href="Registration.php">Waste Producer</a></li>
                                                    <li><a href="CollectorRegister.php">Waste Collector</a></li>
                                                   
                                                </ul> 
                                            </li>
                                        </ul>
                                    </nav>
                                </div>  
                            </div>
                            <!-- <div class="col-md-3 col-lg-2 col-sm-4 col-xs-4">
                                <div class="header__right">
                                    <div class="header__search search search__open">
                                        <a href="#"><i class="icon-magnifier icons"></i></a>
                                    </div> -->
                                 <!-------------------account--------------------->

                                <!----yhan se htaya he cart view icon---->
                                <!-- </div>
                            </div> -->
                        </div>
                    </div>
                    <div class="mobile-menu-area"></div>
                </div>
            </div>
            <!-- End Mainmenu Area -->
        </header>
        <!-- End Header Area -->
        <section class="sec-2" style="height:700px;background-color:white;">
	<h2 class="h2-heading" style="text-align:center;"><bold>Welcome to iRecyclerz Recycling</bold></h2>
	<h3 class="h3" style="color: black; font-family: serif; margin-top:20px;">more about Us</h3>
	<p class="para" style="font-size:15px;text-align: center;padding-right:250px;padding-left:220px;color: gray; font-family: 'Poppins', sans-serif;margin-top:20px;">
		iRecyclerz is the bridge between the waste collectors and waste 
producers to serves better and easy communication .This is provideing 
the recycling servives of different types of waste .The aim is to make 
environment free of waste.We deal with every kind of waste that either be hazardious and 
non-hazardious .our services are available in the following waste.
	</p>
	<h4 class="h4" style="font-family: 'Snell Roundhand',Cursive;margin-top:20px;">iRecyclerz</h4>
<div class="content-box">
	<div class="box" style="width:300px;margin-left:80px;">
		<img src="../image/leaf(1).png" style="width:60px;height:60px;margin-top:-60px;"><h4 class="h4-heading">Reuse the item ,it reduced the 
environment waste and make 
environment friendly</h4>
	</div>
	<div class="box"style="width:300px;margin-left:80px;">
		<img src="../image/leaf(1).png" style="width:60px;height:60px;margin-top:-60px;"><h4 class="h4-heading">Reuse the item ,it reduced the 
environment waste and make 
environment friendly</h4>
	</div>
	<div class="box" style="width:300px;margin-left:80px;">
		<img src="../image/leaf(1).png" style="width:60px;height:60px;margin-top:-60px;"><h4 class="h4-heading">Reuse the item ,it reduced the 
environment waste and make 
environment friendly</h4>
	</div>
</div>	
</section>



<section class="marg" style="width:1000px;height:400px;background-color:#b9f5b3;margin-left:210px;margin-bottom:70px;margin-top:-20px;">
<figure class="swing">
  <img src="../image/leaf(1).png" style="width:350px;height:300px;" >
</figure>  
<p  class="bb" style="margin-top:100px; padding-top:40px; text-align:center; color:gray;font-size:22px;font-family:cursive;">Recycling is the process of converting waste materials 
into new materials and objects. The recovery of energy 
from waste materials is often included in this concept. 
The recyclability of a material depends on its ability to 
reacquire the properties it had in its virgin or original 
state.Recycling is the process of converting waste materials 
into new materials and objects. The recovery of energy 
from waste materials is often included in this concept. 
The recyclability of a material depends on its ability to 
reacquire the properties it had in its virgin or original 
state.</p>
</section>
        

        <!-- End Contact Area -->
        <!-- End Banner Area -->
        <!-- Start Footer Area -->
             <!-- Start Footer Area -->
             <footer id="htc__footer">
            <!-- Start Footer Widget -->
            <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">ABOUT US</h2>
                                <div class="ft__details">
                                    <p>Make Request to make your service done.We will be pleased to accept your request and will definetly try to complete the requested service accoplished to make your environment safe.The recovery of energy 
from waste materials is often included in this concept.Make Request to make your service done.We will be pleased to accept your request and will definetly try to complete the requested service accoplished to make your environment safe.</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Categories</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Waste Producer</a></li>
                                        <li><a href="#">Waste Collector</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Sub Categories</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Hazard</a></li>
                                        <li><a href="cart.html">Non Hazard</a></li>
                                      
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Quik link</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">About us</a></li>
                                        <li><a href="cart.html">Contact us</a></li>
                                        <li><a href="#">Login</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Address</h2>
                                <a><p>Jinnah university for women
                                       5-c Nazimabad,karachi</p></a><br>
                                <div class="ft__inner">
                                <h2 class="title__line--2">Phone</h2>
                                    <ul class="ft__list">
                                   
              <li><a href="http://scanfcode.com/sitemap/">034-5894562</a></li>

              <li><a href="http://scanfcode.com/sitemap/">034-5894562</a></li>

              <li><a href="http://scanfcode.com/sitemap/">034-5894562</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                     
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
            </div>
            <!-- End Footer Widget -->
            <!-- Start Copyright Area -->
            <div class="htc__copyright bg__cat--5">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="copyright__inner">
                                <p>Copyright© </p>
                                <!-- <a href="#"><img src="images/others/shape/paypol.png" alt="payment images"></a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copyright Area -->
        </footer>
        <!-- End Footer Style -->
    </div>
    <!-- Body main wrapp-->
  

    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- jquery latest version -->
    <script src="js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="js/plugins.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/ajax-mail.js"></script>

    
    <!-- Waypoints.min.js. -->
    <script src="js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="js/main.js"></script>

</body>

</html>