<?php 
include "dbcon.php";
if(session_status() == PHP_SESSION_NONE)
{
	session_start();//start session if session not start
}

if(isset($_POST['typ']) && isset($_POST['wei']) && isset($_POST['Priceperkg'])&& isset($_POST['type_id'])){
	$type_name = $_POST['typ'];
	$weight = $_POST['wei'];
	$Priceperkg = $_POST['Priceperkg'];
	$type_id = $_POST['type_id'];
	$_SESSION['type_id'] = $type_id;
	$_SESSION['type_name'] = $type_name;
	$_SESSION['weight'] = $weight;
	$_SESSION['Priceperkg'] = $Priceperkg;
	$_SESSION['tracker'] = uniqid();
 //echo $weight ;
	$return['url'] = 'type.php?cat_id='.$_POST['cat_id'];;
	$return['valid'] = true;

	echo json_encode($return);
}//end isset