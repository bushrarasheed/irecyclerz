<?php 
require_once('dbcon.php');
if(session_status() == PHP_SESSION_NONE)
{
	session_start();//start session if session not start
}
//$db = new Database();
$tracker = $_SESSION['tracker'];

$sql = "SELECT *
		FROM user_service_detail b 
		INNER JOIN grabage_type a 
		ON b.type_id = a.type_id
		WHERE tracker = ?;
";
$res=mysqli_query($con,$sql);
echo $res;
// $bookPass = $con->getRows($sql);
// echo $bookPass;

$sqlBookBy = "SELECT * 
			  FROM user_service_detail
			  WHERE tracker = ?
			  LIMIT 1;
";

// $bookByInfo = $con->getRow($sqlBookBy, [$tracker]);

// $return['valid'] = true;
// $return['url'] = "payment.php";

// echo json_encode($return);

//$con->Disconnect();