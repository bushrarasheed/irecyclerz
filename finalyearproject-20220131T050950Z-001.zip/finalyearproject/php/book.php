<?php
include "dbcon.php";
if(session_status() == PHP_SESSION_NONE)
{
	session_start();//start session if session not start
}

if (isset($_POST['username']) && isset($_POST['organization']) && isset($_POST['email'])) {
    // echo 'yes';
    $user=$_POST['username'];
    $organization =$_POST['organization'];
    $mail = $_POST['email'];

    $userid = $_POST['userid'];
    $status = $_POST['status'];
    $_SESSION['user'] = $user;
	$_SESSION['organization'] = $organization;
	$_SESSION['mail'] = $mail ;
    $type_id= $_SESSION['type_id'] ;
    $type_name=$_SESSION['type_name'];
	$weight=$_SESSION['weight'];
    $Priceperkg = $_SESSION['Priceperkg'];
    $loc=$_SESSION['loc'];
	$PickupDate=$_SESSION['Pickup_date'];                                       
    $tracker = $_SESSION['tracker']; 
   

    $sql = "insert into user_service_detail (user, organization,mail, loc, type_name, weight, Pickup_date,Priceperkg,
			 tracker,userid,type_id,status)
			 values('$user', '$organization','$mail', '$loc', '$type_name', '$weight', '$PickupDate','$Priceperkg', '$tracker','".$_SESSION['id']."','$type_id','pending')

	";
    
     
    $result=mysqli_query($con,$sql);
    
    
    $return['url'] = 'slip.php?cat_id='.$_POST['cat_id'];
    $return['valid'] = true;

    // if ($result)
    // {
           
    //     $subject = "Service Form";
    //     $email_body = "Your Type:\n";
    
    
    //     $from = "irecyclerz@gmail.com";
    //     $header='';
    //     $header .= 'MIME-Version: 1.0' . "\r\n";
    //     $header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    //     $header .= "From: $mail \r\n" .
    //             "Reply-To: $mail \r\n" .
    //             "X-Mailer: PHP/" . phpversion();
    //     mail($mail, $subject, $email_body, $header);
        
    // }  
    

    echo json_encode($return);
}
?>